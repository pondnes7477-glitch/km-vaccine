import React, { useState, useEffect } from 'react';

export default function VaccineScheduler() {
  const [dob, setDob] = useState('');
  const [results, setResults] = useState(null);

  const MILESTONES = [
    { months: 2, label: '2 เดือน', wed: 1 },
    { months: 4, label: '4 เดือน', wed: 1 },
    { months: 6, label: '6 เดือน', wed: 1 },
    { months: 9, label: '9 เดือน', wed: 3 },
    { months: 12, label: '1 ปี (12 เดือน)', wed: 3 },
    { months: 18, label: '1 ปี 6 เดือน (18 เดือน)', wed: 1 },
    { months: 30, label: '2 ปี 6 เดือน (30 เดือน)', wed: 3 },
    { months: 48, label: '4 ปี (48 เดือน)', wed: 1 }
  ];

  function addMonths(date, months) {
    const d = new Date(date.getTime());
    const day = d.getDate();
    d.setMonth(d.getMonth() + months);
    if (d.getDate() !== day) d.setDate(0);
    return d;
  }

  function firstAndThirdWednesdays(year, month) {
    const first = new Date(year, month, 1);
    const offset = (3 - first.getDay() + 7) % 7;
    const firstWed = new Date(year, month, 1 + offset);
    const thirdWed = new Date(year, month, firstWed.getDate() + 14);
    return { firstWed, thirdWed };
  }

  function sameWedNextMonth(date) {
    const y = date.getFullYear();
    const m = date.getMonth();
    const isFirst = date.getDate() <= 14;
    let nextM = m + 1, nextY = y;
    if (nextM > 11) { nextM = 0; nextY++; }
    const { firstWed, thirdWed } = firstAndThirdWednesdays(nextY, nextM);
    return isFirst ? firstWed : thirdWed;
  }

  const formatDate = (d) => d.toLocaleDateString('th-TH', { year: 'numeric', month: 'short', day: 'numeric' });

  function handleCalculate(e) {
    e.preventDefault();
    if (!dob) return;
    const birth = new Date(dob + 'T00:00:00');
    const schedule = MILESTONES.map((m) => {
      const target = addMonths(birth, m.months);
      const { firstWed, thirdWed } = firstAndThirdWednesdays(target.getFullYear(), target.getMonth());
      let appointmentDate = m.wed === 1 ? firstWed : thirdWed;
      if (appointmentDate < target) appointmentDate = sameWedNextMonth(appointmentDate);
      return { milestone: m.label, milestoneDate: formatDate(target), appointment: formatDate(appointmentDate), wed: m.wed };
    });
    setResults({ birth: formatDate(birth), schedule });
  }

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/service-worker.js').catch(()=>{});
    }
  }, []);

  return (
    <div style={{minHeight: '100vh', background: 'linear-gradient(180deg,#ffffff,#e6f9fb)', padding: 20, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
      <div style={{width: '100%', maxWidth: 900, background: '#fff', borderRadius: 16, padding: 24, boxShadow: '0 6px 20px rgba(0,0,0,0.08)'}}>
        <h1 style={{textAlign:'center', color:'#0ea5a4'}}>รพ.สต. โขมง — ระบบคำนวณและนัดฉีดวัคซีนเด็ก</h1>
        <p style={{textAlign:'center', color:'#6b7280'}}>คำนวณและนัดฉีดวัคซีนเด็ก (พุธที่ 1 / พุธที่ 3)</p>

        <form onSubmit={handleCalculate} style={{display:'flex', gap:12, marginTop:16, flexWrap:'wrap'}}>
          <label style={{flex:1}}>
            <div style={{fontSize:13,color:'#374151', marginBottom:6}}>วัน/เดือน/ปีเกิดของเด็ก</div>
            <input type="date" value={dob} onChange={(e)=>setDob(e.target.value)} style={{width:'100%', padding:8, borderRadius:8, border:'1px solid #d1d5db'}} required />
          </label>
          <div style={{display:'flex', alignItems:'flex-end'}}>
            <button style={{background:'#06b6d4', color:'#fff', padding:'10px 16px', borderRadius:8, border:'none'}}>คำนวณ & สร้างนัด</button>
          </div>
        </form>

        {results && (
          <div style={{marginTop:20, background:'#f0fdfa', padding:12, borderRadius:10}}>
            <h2 style={{color:'#15803d'}}>ผลการคำนวณ</h2>
            <div style={{color:'#374151', marginBottom:8}}>วันเกิด: {results.birth}</div>
            {results.schedule.map(s => (
              <div key={s.milestone} style={{display:'flex', justifyContent:'space-between', padding:10, background:'#fff', borderRadius:8, marginBottom:8, border:'1px solid #e6f4f4'}}>
                <div>
                  <div style={{fontWeight:600}}>{s.milestone}</div>
                  <div style={{fontSize:12, color:'#6b7280'}}>กำหนดอายุ: {s.milestoneDate}</div>
                </div>
                <div style={{textAlign:'right'}}>
                  <div style={{fontWeight:700, color:'#065f46'}}>นัด: {s.appointment}</div>
                  <div style={{fontSize:12, color:'#6b7280'}}>(พุธที่ {s.wed})</div>
                </div>
              </div>
            ))}
          </div>
        )}

        <footer style={{textAlign:'center', color:'#6b7280', marginTop:18, fontSize:12}}>ธีม: ฟ้า-เขียว-ขาว • รองรับการติดตั้งเป็นแอป (PWA)</footer>
      </div>
    </div>
  );
}
