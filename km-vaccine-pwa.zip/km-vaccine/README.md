KM Vaccine — PWA-ready React scaffold

ไฟล์นี้เป็นโปรเจกต์ React (scaffold) ที่เตรียมไว้ให้สำหรับใช้งานเป็น PWA และนำไป deploy บน GitHub Pages

คำแนะนำสั้นๆ เพื่อ deploy ขึ้น GitHub Pages:
1. แตกไฟล์ ZIP ลงในเครื่อง
2. ติดตั้ง Node.js (LTS) จาก https://nodejs.org
3. เปิด Terminal ในโฟลเดอร์โปรเจกต์ และรัน:
   npm install
4. (ทดสอบในเครื่อง) รัน:
   npm start
5. สร้าง build สำหรับ deploy:
   npm run build
6. หากต้องการ deploy ไปยัง GitHub Pages อัตโนมัติ:
   - แก้ไข field "homepage" ใน package.json เป็น: https://<USERNAME>.github.io/km-vaccine
   - ติดตั้ง gh-pages: npm install --save-dev gh-pages
   - จากนั้นรัน: npm run deploy
   Alternately: upload the build/ folder content directly into your GitHub repository and enable Pages to serve from root.

ติดตั้งบน Android (หลัง deploy):
1. เปิด URL ที่ได้จากการ deploy ใน Chrome บน Android
2. กดเมนู (สามจุด) -> Add to Home screen
3. ตั้งชื่อแล้วเพิ่มได้เลย — จะใช้งานเป็นแอป PWA
